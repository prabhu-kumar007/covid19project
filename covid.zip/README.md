<div align="center">
 <h1>Covid-19 Country Stats</h1>
 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/SARS-CoV-2_without_background.png/800px-SARS-CoV-2_without_background.png" width="128">
</div>

# [Live Preview](https://jadennns-covid19-country.netlify.app/)

- Preview Images
  ![Example 1](https://cdn.discordapp.com/attachments/958550419334918185/965468499772334110/unknown.png)
  ![Example 2](https://cdn.discordapp.com/attachments/958550419334918185/965468676407050270/unknown.png)

* Utilities :
  [Next.JS](https://nextjs.org/)
  [react-simple-maps](https://react-simple-maps.io/)
  [disease.sh](https://disease.sh/)
  [react-tooltip](https://npmjs.com/package/react-tooltip)

Made By: [jadennns](https://jadennns.netlify.app)
"# covid19project" 
"# covid19project" 
